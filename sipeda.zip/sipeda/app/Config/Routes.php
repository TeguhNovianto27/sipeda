<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth::index');
$routes->delete('/dtks/(:num)', 'dtks::delete/$1');
$routes->delete('/pkh/(:num)', 'Pkh::delete/$1');
$routes->delete('/bpnt/(:num)', 'Bpnt::delete/$1');
$routes->delete('/pengaturan/(:num)', 'Pengaturan::delete/$1');
$routes->delete('/disabilitas/(:num)', 'Disabilitas::delete/$1');

// $routes->add('warga/')