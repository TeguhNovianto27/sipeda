<?php

namespace App\Controllers;

use App\Models\Model_auth;

class Auth extends BaseController
{
    protected $Model_auth;

    public function __construct()
    {
        $this->Model_auth = new Model_auth();
    }

    public function index()
    {
        $data = [
            'title' => 'Login'
        ];
        return view('auth/login', $data);
    }

    public function login()
    {
        if ($this->validate([
            'username' => [
                'label' => 'Username',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'password' => [
                'label' => 'Password',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
        ])) {
            //valid
            $username = $this->request->getPost('username');
            $password = sha1($this->request->getPost('password'));
            $cek = $this->Model_auth->login($username, $password);
            if ($cek) {
                //jika login berhasil
                session()->set('log', true);
                session()->set('id_auth', $cek['id_auth']);
                session()->set('nama_pengguna', $cek['nama_pengguna']);
                session()->set('role', $cek['role']);
                if ($cek['role'] == '1') {
                    return redirect()->to(base_url('admin'));
                } else {
                    return redirect()->to(base_url('petugas'));
                }
            } else {
                //jika login gagal
                session()->setFlashdata('gagal', 'username dan password tidak valid');
                return redirect()->to(base_url('/auth'));
            }
        } else {
            session()->setFlashdata('errors', \Config\Services::validation()->getErrors());
            return redirect()->to(base_url('/auth'));
        }
    }

    public function logout()
    {
        session()->remove('log');
        session()->remove('id_auth');
        session()->remove('nama_pengguna');
        session()->remove('role');
        session()->remove('username');
        session()->remove('password');
        session()->setFlashdata('logout', 'Anda Berhasil LogOut');
        return redirect()->to(base_url('/auth'));
    }
}
