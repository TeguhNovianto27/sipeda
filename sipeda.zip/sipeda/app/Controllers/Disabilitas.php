<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Model_disabilitas;

class Disabilitas extends BaseController
{
    protected $Model_disabilitas;

    public function __construct()
    {
        $this->Model_disabilitas = new Model_disabilitas();
    }

    public function index()
    {
        $data = [
            'title' => 'Data Warga Disabilitas',
            'disabilitas' => $this->Model_disabilitas->all_data(),
        ];

        return view('disabilitas/index', $data);
    }

    public function tambah()
    {
        $data = [
            'title' => 'Tambah Data Warga Disabilitas',
        ];

        return view('disabilitas/tambah', $data);
    }

    public function add()
    {
        if ($this->validate([
            'nik' => [
                'label' => 'NIK',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'nama' => [
                'label' => 'Nama',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'tgl_lahir' => [
                'label' => 'Tanggal Lahir',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'alamat' => [
                'label' => 'Alamat',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_kelamin' => [
                'label' => 'Jenis Kelamin',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_disabilitas' => [
                'label' => 'Jenis Kebutuhan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'kebutuhan' => [
                'label' => 'Kebutuhan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
        ])) {
            $data = array(
                'tanggal' => date('Y-m-d h:i:s'),
                'nik' => $this->request->getPost('nik'),
                'nama' => $this->request->getPost('nama'),
                'tgl_lahir' => $this->request->getPost('tgl_lahir'),
                'alamat' => $this->request->getPost('alamat'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'jenis_disabilitas' => $this->request->getPost('jenis_disabilitas'),
                'kebutuhan' => $this->request->getPost('kebutuhan'),
            );
            $this->Model_disabilitas->add($data);
            session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
            return redirect()->to(base_url('disabilitas'));
        } else {
            //jika tidak valid
            $validation = \Config\Services::validation()->getErrors();
            session()->setFlashdata('errors', $validation);
            return redirect()->to(base_url('disabilitas/tambah'))->withInput();
        }
    }

    public function edit($id_disabilitas)
    {
        $data = [
            'title' => 'Edit Data Warga Disabilitas',
            'disabilitas' => $this->Model_disabilitas->detail($id_disabilitas),
        ];

        return view('disabilitas/edit', $data);
    }

    public function update($id_disabilitas)
    {
        if ($this->validate([
            'nik' => [
                'label' => 'NIK',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'nama' => [
                'label' => 'Nama',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'tgl_lahir' => [
                'label' => 'Tanggal Lahir',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'alamat' => [
                'label' => 'Alamat',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_kelamin' => [
                'label' => 'Jenis Kelamin',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_disabilitas' => [
                'label' => 'Jenis Kebutuhan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'kebutuhan' => [
                'label' => 'Kebutuhan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
        ])) {
            $data = array(
                'id_disabilitas' => $id_disabilitas,
                'nik' => $this->request->getPost('nik'),
                'nama' => $this->request->getPost('nama'),
                'tgl_lahir' => $this->request->getPost('tgl_lahir'),
                'alamat' => $this->request->getPost('alamat'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'jenis_disabilitas' => $this->request->getPost('jenis_disabilitas'),
                'kebutuhan' => $this->request->getPost('kebutuhan'),
            );
            $this->Model_disabilitas->edit($data);
            session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
            return redirect()->to(base_url('disabilitas'));
        } else {
            //jika tidak valid
            $validation = \Config\Services::validation()->getErrors();
            session()->setFlashdata('errors', $validation);
            return redirect()->to(base_url('disabilitas/edit/' . $id_disabilitas))->withInput();
        }
    }

    public function delete($id_auth)
    {
        $this->Model_disabilitas->delete($id_auth);
        session()->setFlashdata('pesan', 'Data Berhasil Dihapus');
        return redirect()->to(base_url('disabilitas'));
    }
}
