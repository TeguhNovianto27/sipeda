<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Model_dtks;

class Dtks extends BaseController
{
    protected $Model_dtks;

    public function __construct()
    {
        $this->Model_dtks = new Model_dtks();
    }

    public function index()
    {
        $data = [
            'title' => 'Data Warga Dtks',
            'dtks' => $this->Model_dtks->all_data(),
        ];

        return view('dtks/index', $data);
    }

    public function tambah()
    {
        $data = [
            'title' => 'Tambah Data Warga dtks',
        ];

        return view('dtks/tambah', $data);
    }

    public function add()
    {
        if ($this->validate([
            'nik' => [
                'label' => 'NIK',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'no_kk'=>[
                'label' => 'NO KK',
                'rules' => 'required',
                'errors' => [
                    'required'=> '{field} wajib diisi'
                ]

            ],
            'nama' => [
                'label' => 'Nama',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'tgl_lahir' => [
                'label' => 'Tanggal Lahir',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'alamat' => [
                'label' => 'Alamat',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_kelamin' => [
                'label' => 'Jenis Kelamin',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'keterangan' => [
                'label' => 'Keterangan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
        
        ])) {
            $data = array(
                'id_dtks' => $this->request->getPost('id_dtks'),
                'no_kk' => $this->request->getPost('no_kk'),
                'nik' => $this->request->getPost('nik'),
                'nama' => $this->request->getPost('nama'),
                'tgl_lahir' => $this->request->getPost('tgl_lahir'),
                'alamat' => $this->request->getPost('alamat'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'keterangan' => $this->request->getPost('keterangan'),
            );
            $this->Model_dtks->add($data);
            session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
            return redirect()->to(base_url('dtks'));
        } else {
            //jika tidak valid
            $validation = \Config\Services::validation()->getErrors();
            session()->setFlashdata('errors', $validation);
            return redirect()->to(base_url('dtks/tambah'))->withInput();
        }
    }

    public function edit($id_dtks)
    {
        $data = [
            'title' => 'Edit Data Warga Dtks',
            'dtks' => $this->Model_dtks->detail($id_dtks),
        ];

        return view('dtks/edit', $data);
    }

    public function update($id_dtks)
    {
        if ($this->validate([
            'no_kk'=>[
                'label' => 'NO KK',
                'rules' => 'required',
                'errors' => [
                    'required'=> '{field} wajib diisi'
                ]

            ],
            'nik' => [
                'label' => 'NIK',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            
            'nama' => [
                'label' => 'Nama',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'tgl_lahir' => [
                'label' => 'Tanggal Lahir',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'alamat' => [
                'label' => 'Alamat',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_kelamin' => [
                'label' => 'Jenis Kelamin',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'keterangan' => [
                'label' => 'Keterangan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            
        ])) {
            $data = array(
                'id_dtks' => $id_dtks,
                'no_kk' => $this->request->getPost('no_kk'),
                'nik' => $this->request->getPost('nik'),
                'nama' => $this->request->getPost('nama'),
                'tgl_lahir' => $this->request->getPost('tgl_lahir'),
                'alamat' => $this->request->getPost('alamat'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'keterangan' => $this->request->getPost('keterangan'),
            );
            $this->Model_dtks->edit($data);
            session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
            return redirect()->to(base_url('dtks'));
        } else {
            //jika tidak valid
            $validation = \Config\Services::validation()->getErrors();
            session()->setFlashdata('errors', $validation);
            return redirect()->to(base_url('dtks/edit/' . $id_dtks))->withInput();
        }
    }

    public function delete($id_auth)
    {
        $this->Model_dtks->delete($id_auth);
        session()->setFlashdata('pesan', 'Data Berhasil Dihapus');
        return redirect()->to(base_url('dtks'));
    }
}