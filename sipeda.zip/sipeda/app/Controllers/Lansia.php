<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Model_lansia;

class Lansia extends BaseController
{
    protected $Model_lansia;

    public function __construct()
    {
        $this->Model_lansia = new Model_lansia();
    }

    public function index()
    {
        $data = [
            'title' => 'Data Warga Lansia',
            'lansia' => $this->Model_lansia->all_data(),
        ];

        return view('lansia/index', $data);
    }

    public function tambah()
    {
        $data = [
            'title' => 'Tambah Data Warga Lansia',
        ];

        return view('lansia/tambah', $data);
    }

    public function add()
    {
        if ($this->validate([
            'nik' => [
                'label' => 'NIK',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'no_kk'=>[
                'label' => 'NO KK',
                'rules' => 'required',
                'errors' => [
                    'required'=> '{field} wajib diisi'
                ]

            ],
            'nama' => [
                'label' => 'Nama',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'tgl_lahir' => [
                'label' => 'Tanggal Lahir',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'alamat' => [
                'label' => 'Alamat',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_kelamin' => [
                'label' => 'Jenis Kelamin',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_lansia' => [
                'label' => 'Jenis Pelayanan Lansia',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
        
        ])) {
            $data = array(
                'id_lansia' => $this->request->getPost('id_lansia'),
                'no_kk' => $this->request->getPost('no_kk'),
                'nik' => $this->request->getPost('nik'),
                'nama' => $this->request->getPost('nama'),
                'tgl_lahir' => $this->request->getPost('tgl_lahir'),
                'alamat' => $this->request->getPost('alamat'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'jenis_lansia' => $this->request->getPost('jenis_lansia'),
            );
            $this->Model_lansia->add($data);
            session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
            return redirect()->to(base_url('lansia'));
        } else {
            //jika tidak valid
            $validation = \Config\Services::validation()->getErrors();
            session()->setFlashdata('errors', $validation);
            return redirect()->to(base_url('lansia/tambah'))->withInput();
        }
    }

    public function edit($id_lansia)
    {
        $data = [
            'title' => 'Edit Data Warga Lansia',
            'lansia' => $this->Model_lansia->detail($id_lansia),
        ];

        return view('lansia/edit', $data);
    }

    public function update($id_lansia)
    {
        if ($this->validate([
            'no_kk'=>[
                'label' => 'NO KK',
                'rules' => 'required',
                'errors' => [
                    'required'=> '{field} wajib diisi'
                ]

            ],
            'nik' => [
                'label' => 'NIK',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            
            'nama' => [
                'label' => 'Nama',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'tgl_lahir' => [
                'label' => 'Tanggal Lahir',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'alamat' => [
                'label' => 'Alamat',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_kelamin' => [
                'label' => 'Jenis Kelamin',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_lansia' => [
                'label' => 'Jenis Pelayanan Lansia',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            
        ])) {
            $data = array(
                'id_lansia' => $id_lansia,
                'no_kk' => $this->request->getPost('no_kk'),
                'nik' => $this->request->getPost('nik'),
                'nama' => $this->request->getPost('nama'),
                'tgl_lahir' => $this->request->getPost('tgl_lahir'),
                'alamat' => $this->request->getPost('alamat'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'jenis_lansia' => $this->request->getPost('jenis_lansia'),
            );
            $this->Model_lansia->edit($data);
            session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
            return redirect()->to(base_url('lansia'));
        } else {
            //jika tidak valid
            $validation = \Config\Services::validation()->getErrors();
            session()->setFlashdata('errors', $validation);
            return redirect()->to(base_url('lansia/edit/' . $id_lansia))->withInput();
        }
    }

    public function delete($id_auth)
    {
        $this->Model_lansia->delete($id_auth);
        session()->setFlashdata('pesan', 'Data Berhasil Dihapus');
        return redirect()->to(base_url('lansia'));
    }
}