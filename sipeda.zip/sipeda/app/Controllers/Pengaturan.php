<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Model_auth;

class Pengaturan extends BaseController
{
    protected $Model_auth;

    public function __construct()
    {
        $this->Model_auth = new Model_auth();
    }

    public function index()
    {
        $data = [
            'title' => 'Data Pengguna',
            'pengaturan' => $this->Model_auth->all_data(),
        ];

        return view('pengaturan/index', $data);
    }

    public function tambah()
    {
        $data = [
            'title' => 'Tambah Data Pengguna',
        ];

        return view('pengaturan/tambah', $data);
    }

    public function add()
    {
        if ($this->validate([
            'nama_pengguna' => [
                'label' => 'Nama Pengguna',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'username' => [
                'label' => 'Username',
                'rules' => 'required|is_unique[auth.username]',
                'errors' => [
                    'required' => '{field} harus diisi',
                    'is_unique' => '{field} sudah terdaftar, silahkan gunakan username yang lain'
                ]
            ],
            'password' => [
                'label' => 'Password',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi'
                ]
            ],
            'role' => [
                'label' => 'Role',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
        ])) {
            $data = array(
                'tanggal' => date('Y-m-d h:i:s'),
                'nama_pengguna' => $this->request->getPost('nama_pengguna'),
                'username' => $this->request->getPost('username'),
                'password' => sha1($this->request->getPost('password')),
                'role' => $this->request->getPost('role'),
            );
            $this->Model_auth->add($data);
            session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
            return redirect()->to(base_url('/pengaturan'));
        } else {
            //jika tidak valid
            $validation = \Config\Services::validation()->getErrors();
            session()->setFlashdata('errors', $validation);
            return redirect()->to(base_url('pengaturan/tambah'))->withInput();
        }
    }

    public function edit($id_auth)
    {
        $data = [
            'title' => 'Edit Data Pengguna',
            'pengaturan' => $this->Model_auth->detail($id_auth),
        ];
        return view('pengaturan/edit', $data);
    }

    public function update($id_auth)
    {
        $usernameLama = $this->Model_auth->all_data($this->request->getVar('id_auth'));
        if ($usernameLama['username'] = $this->request->getPost('username')) {
            $rule_username = 'required';
        } else {
            $rule_username = 'required|is_unique[auth.username]';
        }

        if ($this->validate([
            'nama_pengguna' => [
                'label' => 'Nama Pengguna',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'username' => [
                'label' => 'Username',
                'rules' => $rule_username,
                'errors' => [
                    'required' => '{field} harus diisi',
                    'is_unique' => '{field} sudah terdaftar, silahkan gunakan username yang lain'
                ]
            ],
            'password' => [
                'label' => 'Password',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi'
                ]
            ],
            'role' => [
                'label' => 'Role',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
        ])) {
            $data = array(
                'id_auth' => $id_auth,
                'nama_pengguna' => $this->request->getPost('nama_pengguna'),
                'username' => $this->request->getPost('username'),
                'password' => sha1($this->request->getPost('password')),
                'role' => $this->request->getPost('role'),
            );
            $this->Model_auth->edit($data);
            session()->setFlashdata('pesan', 'Data Berhasil Diubah');
            return redirect()->to(base_url('pengaturan'));
        } else {
            //jika tidak valid
            session()->setFlashdata('errors', \Config\Services::validation()->getErrors());
            return redirect()->to(base_url('pengaturan/edit/' . $id_auth));
        }
    }

    public function delete($id_auth)
    {
        $this->Model_auth->delete($id_auth);
        session()->setFlashdata('pesan', 'Data Berhasil Dihapus');
        return redirect()->to(base_url('pengaturan'));
    }
}
