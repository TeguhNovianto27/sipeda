<?php

namespace App\Controllers;

use App\Models\Model_warga;

class Pkh extends BaseController
{
    protected $Model_warga;

    public function __construct()
    {
        $this->Model_warga = new Model_warga();
    }

    public function index(): string
    {
        $data = [
            'title' => 'Data PKH',
            'pkh' => $this->Model_warga->pilih_pkh(),
        ];

        return view('pkh/index', $data);
    }

    public function delete($id_warga)
    {
        $this->Model_warga->delete($id_warga);
        session()->setFlashdata('pesan', 'Data Berhasil Dihapus');
        return redirect()->to(base_url('pkh'));
    }
}
