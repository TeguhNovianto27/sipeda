<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Model_warga;

class Warga extends BaseController
{
    protected $Model_warga;

    public function __construct()
    {
        $this->Model_warga = new Model_warga();
    }

    // public function index()
    // {
    //     $data = [
    //         'title' => 'Data Penduduk',
    //         'warga' => $this->Model_warga->all_data(),
    //     ];

    //     return view('warga/index', $data);
    // }

    public function tambah()
    {
        $data = [
            'title' => 'Tambah Data PKH/BPNT',
        ];

        return view('warga/tambah', $data);
    }

    public function add()
    {
        if ($this->validate([
            'no_kk' => [
                'label' => 'No. KK',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'nik' => [
                'label' => 'NIK',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'nama' => [
                'label' => 'Nama',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'alamat' => [
                'label' => 'Alamat',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'tgl_lahir' => [
                'label' => 'Tanggal Lahir',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_kelamin' => [
                'label' => 'Jenis Kelamin',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'no_hp' => [
                'label' => 'No. Telepon',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'agama' => [
                'label' => 'Agama',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'pekerjaan' => [
                'label' => 'Pekerjaan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'pakaian' => [
                'label' => 'Pakaian',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'biaya_pengobatan' => [
                'label' => 'Biaya Pengobatan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'makanan_per_hari' => [
                'label' => 'Makanan Per Hari',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'penerima_bantuan' => [
                'label' => 'Penerima Bantuan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
        ])) {
            $data = array(
                'tanggal' => date('Y-m-d h:i:s'),
                'no_kk' => $this->request->getPost('no_kk'),
                'nik' => $this->request->getPost('nik'),
                'nama' => $this->request->getPost('nama'),
                'alamat' => $this->request->getPost('alamat'),
                'tgl_lahir' => $this->request->getPost('tgl_lahir'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'no_hp' => $this->request->getPost('no_hp'),
                'agama' => $this->request->getPost('agama'),
                'pekerjaan' => $this->request->getPost('pekerjaan'),
                'pakaian' => $this->request->getPost('pakaian'),
                'biaya_pengobatan' => $this->request->getPost('biaya_pengobatan'),
                'makanan_per_hari' => $this->request->getPost('makanan_per_hari'),
                'penerima_bantuan' => $this->request->getPost('penerima_bantuan'),
            );
            $this->Model_warga->add($data);
            if ($this->request->getPost('penerima_bantuan') == '1') {
                session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
                return redirect()->to(base_url('bpnt'));
            } else {
                session()->setFlashdata('pesan', 'Data Berhasil Ditambahkan');
                return redirect()->to(base_url('pkh'));
            }
        } else {
            //jika tidak valid
            $validation = \Config\Services::validation()->getErrors();
            session()->setFlashdata('errors', $validation);
            return redirect()->to(base_url('warga/tambah'))->withInput();
        }
    }

    public function edit($id_warga)
    {
        $data = [
            'title' => 'Edit Data Penduduk',
            'warga' => $this->Model_warga->detail($id_warga),
        ];

        return view('warga/edit', $data);
    }

    public function update($id_warga)
    {
        if ($this->validate([
            'no_kk' => [
                'label' => 'No. KK',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'nik' => [
                'label' => 'NIK',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'nama' => [
                'label' => 'Nama',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} wajib diisi !'
                ]
            ],
            'alamat' => [
                'label' => 'Alamat',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'tgl_lahir' => [
                'label' => 'Tanggal Lahir',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'jenis_kelamin' => [
                'label' => 'Jenis Kelamin',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'no_hp' => [
                'label' => 'No. Telepon',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'agama' => [
                'label' => 'Agama',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'pekerjaan' => [
                'label' => 'Pekerjaan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'pakaian' => [
                'label' => 'Pakaian',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'biaya_pengobatan' => [
                'label' => 'Biaya Pengobatan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'makanan_per_hari' => [
                'label' => 'Makanan Per Hari',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
            'penerima_bantuan' => [
                'label' => 'Penerima Bantuan',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} harus diisi !'
                ]
            ],
        ])) {
            $data = array(
                'id_warga' => $id_warga,
                'no_kk' => $this->request->getPost('no_kk'),
                'nik' => $this->request->getPost('nik'),
                'nama' => $this->request->getPost('nama'),
                'alamat' => $this->request->getPost('alamat'),
                'tgl_lahir' => $this->request->getPost('tgl_lahir'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'no_hp' => $this->request->getPost('no_hp'),
                'agama' => $this->request->getPost('agama'),
                'pekerjaan' => $this->request->getPost('pekerjaan'),
                'pakaian' => $this->request->getPost('pakaian'),
                'biaya_pengobatan' => $this->request->getPost('biaya_pengobatan'),
                'makanan_per_hari' => $this->request->getPost('makanan_per_hari'),
                'penerima_bantuan' => $this->request->getPost('penerima_bantuan'),
            );
            $this->Model_warga->edit($data);
            if ($this->request->getPost('penerima_bantuan') == '1') {
                session()->setFlashdata('pesan', 'Data Berhasil Diubah');
                return redirect()->to(base_url('bpnt'));
            } else {
                session()->setFlashdata('pesan', 'Data Berhasil Diubah');
                return redirect()->to(base_url('pkh'));
            }
        } else {
            //jika tidak valid
            $validation = \Config\Services::validation()->getErrors();
            session()->setFlashdata('errors', $validation);
            return redirect()->to(base_url('warga/edit/' . $id_warga))->withInput();
        }
    }
}
