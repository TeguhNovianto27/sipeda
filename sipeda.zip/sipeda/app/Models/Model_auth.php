<?php

namespace App\Models;

use CodeIgniter\Model;

class Model_auth extends Model
{
    protected $table = 'auth';
    protected $primaryKey = 'id_auth';

    public function login($username, $password)
    {
        return $this->db->table('auth')->where([
            'username' => $username,
            'password' => $password,
        ])->get()->getRowArray();
    }

    public function all_data()
    {
        return $this->db->table('auth')
            ->orderBy('tanggal', 'desc')
            ->get()->getResult();
    }

    public function add($data)
    {
        $this->db->table('auth')->insert($data);
    }

    public function detail($id_auth)
    {
        return $this->db->table('auth')
            ->where('id_auth', $id_auth)
            ->get()->getRowArray();
    }

    public function edit($data)
    {
        $this->db->table('auth')
            ->where('id_auth', $data['id_auth'])
            ->update($data);
    }
}
