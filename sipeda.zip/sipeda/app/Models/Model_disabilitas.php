<?php

namespace App\Models;

use CodeIgniter\Model;

class Model_disabilitas extends Model
{
    protected $table = 'disabilitas';
    protected $primaryKey = 'id_disabilitas';

    public function all_data()
    {
        return $this->db->table('disabilitas')
            ->orderBy('tanggal', 'desc')
            ->get()->getResult();
    }

    public function add($data)
    {
        $this->db->table('disabilitas')->insert($data);
    }

    public function detail($id_disabilitas)
    {
        return $this->db->table('disabilitas')
            ->where('id_disabilitas', $id_disabilitas)
            ->get()->getRowArray();
    }

    public function edit($data)
    {
        $this->db->table('disabilitas')
            ->where('id_disabilitas', $data['id_disabilitas'])
            ->update($data);
    }
}
