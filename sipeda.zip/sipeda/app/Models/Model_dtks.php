<?php

namespace App\Models;

use CodeIgniter\Model;

class Model_dtks extends Model
{
    protected $table = 'dtks';
    protected $primaryKey = 'id_dtks';

    public function all_data()
    {
        return $this->db->table('dtks')
            ->orderBy('id_dtks', 'desc')
            ->get()->getResult();
    }

    public function add($data)
    {
        $this->db->table('dtks')->insert($data);
    }

    public function detail($id_dtks)
    {
        return $this->db->table('dtks')
            ->where('id_dtks', $id_dtks)
            ->get()->getRowArray();
    }

    public function edit($data)
    {
        $this->db->table('dtks')
            ->where('id_dtks', $data['id_dtks'])
            ->update($data);
    }
}