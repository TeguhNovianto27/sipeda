<?php

namespace App\Models;

use CodeIgniter\Model;

class Model_lansia extends Model
{
    protected $table = 'lansia';
    protected $primaryKey = 'id_lansia';

    public function all_data()
    {
        return $this->db->table('lansia')
            ->orderBy('id_lansia', 'desc')
            ->get()->getResult();
    }

    public function add($data)
    {
        $this->db->table('lansia')->insert($data);
    }

    public function detail($id_lansia)
    {
        return $this->db->table('lansia')
            ->where('id_lansia', $id_lansia)
            ->get()->getRowArray();
    }

    public function edit($data)
    {
        $this->db->table('lansia')
            ->where('id_lansia', $data['id_lansia'])
            ->update($data);
    }
}