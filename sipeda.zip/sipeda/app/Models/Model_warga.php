<?php

namespace App\Models;

use CodeIgniter\Model;

class Model_warga extends Model
{
    protected $table = 'warga';
    protected $primaryKey = 'id_warga';

    public function all_data()
    {
        return $this->db->table('warga')
            ->orderBy('tanggal', 'desc')
            ->get()->getResult();
    }

    public function add($data)
    {
        $this->db->table('warga')->insert($data);
    }

    public function detail($id_warga)
    {
        return $this->db->table('warga')
            ->where('id_warga', $id_warga)
            ->get()->getRowArray();
    }

    public function edit($data)
    {
        $this->db->table('warga')
            ->where('id_warga', $data['id_warga'])
            ->update($data);
    }

    public function pilih_bpnt()
    {
        return $this->db->table('warga')
            ->where('penerima_bantuan', '1')
            ->orderBy('tanggal', 'desc')
            ->get()->getResult();
    }

    public function pilih_pkh()
    {
        return $this->db->table('warga')
            ->where('penerima_bantuan', '2')
            ->orderBy('tanggal', 'desc')
            ->get()->getResult();
    }
}
