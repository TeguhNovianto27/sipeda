<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?= $title; ?></title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?= base_url(); ?>/css/sb-admin-2.min.css" rel="stylesheet">

    <style>
        body {
            background-image: url('/img/dinsos.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }

        body {
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>

<!-- <body class="bg-gradient-primary"> -->

<body>

    <div class="container">

        <div class="row justify-content-center">

            <div class="col-sm-5">

                <div class="card o-hidden border-0 shadow-lg my-5">

                    <div class="card-header text-center">
                        <a href="<?= base_url('/admin'); ?>" class="h1">SI-PEDA</a><br>
                        <a href="<?= base_url('/admin'); ?>" class="h5">Sistem Informasi Pengelolaan Data</a>
                        <img src="/img/logo_pkl.png" alt="Logo Kabupaten Pekalongan" srcset="">
                    </div>
                    <div class="card-body">

                        <form action="auth/login" method="post">
                            <?php
                            $errors = session()->getFlashdata('errors');
                            if (!empty($errors)) { ?>
                                <div class="alert alert-danger alert-dismissible">
                                    <ul>
                                        <?php foreach ($errors as $key => $value) { ?>
                                            <li><?= esc($value); ?></li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            <?php } ?>
                            <?php if (session()->getFlashdata('gagal')) : ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <?= session()->getFlashdata('gagal'); ?>
                                </div>
                            <?php endif; ?>

                            <?php if (session()->getFlashdata('logout')) : ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?= session()->getFlashdata('logout'); ?>
                                </div>
                            <?php endif; ?>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" id="username" name="username" placeholder="Masukkan Username" autofocus>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control form-control-user" id="password" name="password" placeholder="Masukkan Password">
                            </div>
                            <button type="submit" class="btn btn-primary btn-user btn-block">
                                Login
                            </button>
                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- <div class="container">

        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card border-0 shadow-lg ju">
                    <div class="card-body p-0">
                        
                        <div class="row">
                            <div class="col-lg-6">
                                <img src="/img/dinsos.jpg" style="height: 630px; width: 460px;" class="rounded">
                            </div>
                            <div class="col-lg-6">
                                <div class="p-3">
                                    <div class="text-center">
                                        <a href="<?= base_url('/auth'); ?>" class="h1">SI-PEDA</a><br>
                                        <a href="<?= base_url('/auth'); ?>" class="h5">Sistem Informasi Pengelolaan Data</a>
                                        <img src="/img/logo_pkl.png" alt="Logo Kabupaten Pekalongan" srcset="">
                                    </div>
                                    <br>
                                    <form action="auth/login" method="post">
                                        <div class="p">
                                            <?php
                                            $errors = session()->getFlashdata('errors');
                                            if (!empty($errors)) { ?>
                                                <div class="alert alert-danger alert-dismissible">
                                                    <ul>
                                                        <?php foreach ($errors as $key => $value) { ?>
                                                            <li><?= esc($value); ?></li>
                                                        <?php } ?>
                                                    </ul>
                                                </div>
                                            <?php } ?>
                                            <?php if (session()->getFlashdata('gagal')) : ?>
                                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                    <?= session()->getFlashdata('gagal'); ?>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (session()->getFlashdata('logout')) : ?>
                                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                    <?= session()->getFlashdata('logout'); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" id="username" name="username" placeholder="Masukkan Username" autofocus>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user" id="password" name="password" placeholder="Masukkan Password">
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-user btn-block">
                                            Login
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> -->


    <!-- Bootstrap core JavaScript-->
    <script src="<?= base_url(); ?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?= base_url(); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?= base_url(); ?>/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?= base_url(); ?>/js/sb-admin-2.min.js"></script>

</body>

</html>