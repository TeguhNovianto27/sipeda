<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="row mb-4">
    <div class="col-8">
        <h3><?= $title; ?></h3>
        <?php
        $errors = session()->getFlashdata('errors');
        if (!empty($errors)) { ?>
            <div class="alert alert-danger alert-dismissible">
                <ul>
                    <?php foreach ($errors as $key => $value) { ?>
                        <li><?= esc($value); ?></li>
                    <?php } ?>
                </ul>
            </div>
        <?php } ?>
    </div>
</div>

<form method="post" action="/disabilitas/add">
    <div class="row">
        <div class="col-12">
            <div class="card shadow mb-4">
                <!-- Card Body -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>NIK</label>
                                <input type="text" maxlength="16" class="form-control" name="nik" value="<?= old('nik'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Nama</label>
                                <input type="text" class="form-control" name="nama" value="<?= old('nama'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Tanggal Lahir</label>
                                <input type="date" class="form-control" name="tgl_lahir" value="<?= old('tgl_lahir'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Alamat</label>
                                <input type="text" class="form-control" name="alamat" value="<?= old('alamat'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                                    <option selected disabled value="">-- Pilih jenis Kelamin --</option>
                                    <option value="1" <?= old('jenis_kelamin') == '1' ? 'selected' : ''; ?>>Laki-Laki</option>
                                    <option value="2" <?= old('jenis_kelamin') == '2' ? 'selected' : ''; ?>>Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Jenis Disabilitas</label>
                                <select class="form-control" id="jenis_disabilitas" name="jenis_disabilitas">
                                    <option selected disabled value="">-- Pilih Jenis Disabilitas --</option>
                                    <option value="1" <?= old('jenis_disabilitas') == '1' ? 'selected' : ''; ?>>Disabilitas Sensorik</option>
                                    <option value="2" <?= old('jenis_disabilitas') == '2' ? 'selected' : ''; ?>>Disabilitas Fisik</option>
                                    <option value="3" <?= old('jenis_disabilitas') == '3' ? 'selected' : ''; ?>>Disabilitas Intelektual</option>
                                    <option value="4" <?= old('jenis_disabilitas') == '4' ? 'selected' : ''; ?>>Disabilitas Mental</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Kebutuhan Alat</label>
                                <select class="form-control" id="kebutuhan" name="kebutuhan">
                                    <option selected disabled value="">-- Pilih Kebutuhan Alat --</option>
                                    <option value="1" <?= old('kebutuhan') == '1' ? 'selected' : ''; ?>>Kursi Roda</option>
                                    <option value="2" <?= old('kebutuhan') == '2' ? 'selected' : ''; ?>>Alat Jalan</option>
                                    <option value="3" <?= old('kebutuhan') == '3' ? 'selected' : ''; ?>>Alat Ukur</option>
                                    <option value="4" <?= old('kebutuhan') == '4' ? 'selected' : ''; ?>>Kaki Palsu</option>
                                    <option value="5" <?= old('kebutuhan') == '5' ? 'selected' : ''; ?>>Tangan Palsu</option>
                                    <option value="6" <?= old('kebutuhan') == '6' ? 'selected' : ''; ?>>Alat Dengar</option>
                                    <option value="7" <?= old('kebutuhan') == '7' ? 'selected' : ''; ?>>Kacamata Lansia</option>
                                    <option value="8" <?= old('kebutuhan') == '8' ? 'selected' : ''; ?>>Roster</option>
                                    <option value="9" <?= old('kebutuhan') == '9' ? 'selected' : ''; ?>>Obat-Obatan</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <button class="btn btn-primary btn-user btn-block" type="submit">
        Simpan
    </button>
</form>

<?= $this->endsection(); ?>