<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="row mb-4">
    <div class="col-8">
        <h3><?= $title; ?></h3>
        <?php
        $errors = session()->getFlashdata('errors');
        if (!empty($errors)) { ?>
        <div class="alert alert-danger alert-dismissible">
            <ul>
                <?php foreach ($errors as $key => $value) { ?>
                <li><?= esc($value); ?></li>
                <?php } ?>
            </ul>
        </div>
        <?php } ?>
    </div>
</div>

<form method="post" action="/dtks/add">
    <div class="row">
        <div class="col-12">
            <div class="card shadow mb-4">
                <!-- Card Body -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>NIK</label>
                                <input type="text" maxlength="16" class="form-control" name="nik"
                                    value="<?= old('nik'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>NO KK</label>
                                <input type="text" maxlength="16" class="form-control" name="no_kk"
                                    value="<?= old('no_kk'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Nama</label>
                                <input type="text" class="form-control" name="nama" value="<?= old('nama'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Tanggal Lahir</label>
                                <input type="date" class="form-control" name="tgl_lahir"
                                    value="<?= old('tgl_lahir'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Alamat</label>
                                <input type="text" class="form-control" name="alamat" value="<?= old('alamat'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                                    <option selected disabled value="">-- Pilih jenis Kelamin --</option>
                                    <option value="1" <?= old('jenis_kelamin') == '1' ? 'selected' : ''; ?>>Laki-Laki
                                    </option>
                                    <option value="2" <?= old('jenis_kelamin') == '2' ? 'selected' : ''; ?>>Perempuan
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Keterangan</label>
                                <select class="form-control" id="keterangan" name="keterangan">
                                    <option selected disabled value="">-- Pilih Jenis Keterangan --</option>
                                    <option value="1" <?= old('keterangan') == '1' ? 'selected' : ''; ?>>Terdaftar DTKS
                                    </option>
                                    <option value="2" <?= old('keterangan') == '2' ? 'selected' : ''; ?>>Tidak Terdaftar
                                        DTKS</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <button class="btn btn-primary btn-user btn-block" type="submit">
        Simpan
    </button>
</form>

<?= $this->endsection(); ?>