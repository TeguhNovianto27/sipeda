<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="row mb-4">
    <div class="col-8">
        <h3><?= $title; ?></h3>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <h3>Selamat Datang Di Website SiPeda</h3>
    </div>
</div>

<?= $this->endsection(); ?>