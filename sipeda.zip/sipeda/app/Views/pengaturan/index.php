<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="row mb-4">
    <div class="col-8">
        <h3><?= $title; ?></h3>
    </div>
    <div class="col-4">
        <a href="<?= base_url('pengaturan/tambah'); ?>" class="btn btn-primary">Tambah Data</a>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <?php if (session()->getFlashdata('pesan')) : ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= session()->getFlashdata('pesan'); ?>
            </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Role</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($pengaturan as $key => $value) { ?>
                        <tr>
                            <th scope="row" class="text-center"><?= $i++; ?></th>
                            <td><?= $value->nama_pengguna; ?></td>
                            <td><?= $value->username; ?></td>
                            <td><?= $value->password; ?></td>
                            <td><?= $value->role == '1' ? 'Admin' : 'Petugas'; ?></td>
                            <td>
                                <a class="btn btn-warning" href="<?= base_url('pengaturan/edit/' . $value->id_auth) ?>"><i class="fa fa-edit"></i>Edit</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?= $this->endsection(); ?>