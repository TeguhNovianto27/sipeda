<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<?php if (session()->get('role') == '1') { ?>

    <div class="row mb-4">
        <div class="col-8">
            <h3><?= $title; ?></h3>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <?php if (session()->getFlashdata('pesan')) : ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= session()->getFlashdata('pesan'); ?>
                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>No.KK</th>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Jenis Kelamin</th>
                            <th>No. Telepon</th>
                            <th>Pekerjaan</th>
                            <th>Jenis Bantuan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($pkh as $key => $value) { ?>
                            <tr>
                                <th scope="row" class="text-center"><?= $i++; ?></th>
                                <td><?= $value->no_kk; ?></td>
                                <td><?= $value->nik; ?></td>
                                <td><?= $value->nama; ?></td>
                                <td><?= $value->alamat; ?></td>
                                <td>
                                    <?php
                                    if ($value->jenis_kelamin == '1') {
                                        echo 'Laki-Laki';
                                    } else {
                                        echo 'Perempuan';
                                    }
                                    ?>
                                </td>
                                <td><?= $value->no_hp; ?></td>
                                <td><?= $value->pekerjaan; ?></td>
                                <td>
                                    <?php
                                    if ($value->penerima_bantuan == '1') {
                                        echo 'BPNT';
                                    } else {
                                        echo 'PKH';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <a class="btn btn-warning my-1" href="<?= base_url('warga/edit/' . $value->id_warga) ?>"><i class="fa fa-edit"></i>Edit</a>
                                    <a class="btn btn-danger" data-toggle="modal" data-target="#delelteModal" href="#"><i class="fa fa-trash"></i>Hapus</a>
                                </td>
                            </tr>

                            <div class="modal fade" id="delelteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-body">Apakah anda yakin ingin menghapus data?</div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Tidak</button>
                                            <form action="/pkh/<?= $value->id_warga ?>" method="post" class="d-inline">
                                                <?= csrf_field(); ?>
                                                <input type="hidden" name="_method" value="DELETE">
                                                <button type="submit" class="btn btn-danger" data-toggle="modal" data-target="#delelteModal">
                                                    Ya
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php } else { ?>

    <div class="row mb-4">
        <div class="col-8">
            <h3><?= $title; ?></h3>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <?php if (session()->getFlashdata('pesan')) : ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= session()->getFlashdata('pesan'); ?>
                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>No.KK</th>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Jenis Kelamin</th>
                            <th>No. Telepon</th>
                            <th>Pekerjaan</th>
                            <th>Jenis Bantuan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($pkh as $key => $value) { ?>
                            <tr>
                                <th scope="row" class="text-center"><?= $i++; ?></th>
                                <td><?= $value->no_kk; ?></td>
                                <td><?= $value->nik; ?></td>
                                <td><?= $value->nama; ?></td>
                                <td><?= $value->alamat; ?></td>
                                <td>
                                    <?php
                                    if ($value->jenis_kelamin == '1') {
                                        echo 'Laki-Laki';
                                    } else {
                                        echo 'Perempuan';
                                    }
                                    ?>
                                </td>
                                <td><?= $value->no_hp; ?></td>
                                <td><?= $value->pekerjaan; ?></td>
                                <td>
                                    <?php
                                    if ($value->penerima_bantuan == '1') {
                                        echo 'BPNT';
                                    } else {
                                        echo 'PKH';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <a class="btn btn-warning my-1" href="<?= base_url('warga/edit/' . $value->id_warga) ?>"><i class="fa fa-edit"></i>Edit</a>

                                    <!-- <a class="btn btn-danger" data-toggle="modal" data-target="#delelteModal" href="#"><i class="fa fa-trash"></i>Hapus</a> -->

                                </td>
                            </tr>

                            <!-- <div class="modal fade" id="delelteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-body">Apakah anda yakin ingin menghapus data?</div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Tidak</button>
                                            <form action="/pkh/<?= $value->id_warga ?>" method="post" class="d-inline">
                                                <?= csrf_field(); ?>
                                                <input type="hidden" name="_method" value="DELETE">
                                                <button type="submit" class="btn btn-danger" data-toggle="modal" data-target="#delelteModal">
                                                    Ya
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div> -->

                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php } ?>

<?= $this->endsection(); ?>