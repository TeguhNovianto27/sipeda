<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="row mb-4">
    <div class="col-8">
        <h3><?= $title; ?></h3>
        <?php
        $errors = session()->getFlashdata('errors');
        if (!empty($errors)) { ?>
            <div class="alert alert-danger alert-dismissible">
                <ul>
                    <?php foreach ($errors as $key => $value) { ?>
                        <li><?= esc($value); ?></li>
                    <?php } ?>
                </ul>
            </div>
        <?php } ?>
    </div>
</div>

<form method="post" action="/warga/update/<?= $warga['id_warga']; ?>">
    <?= csrf_field(); ?>
    <div class="row">
        <div class="col-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-b$warga text-primary">Data Individu</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>No. KK</label>
                                <input type="text" maxlength="16" class="form-control" name="no_kk" value="<?= $warga['no_kk']; ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>NIK</label>
                                <input type="text" maxlength="16" class="form-control" name="nik" value="<?= $warga['nik']; ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Nama Penduduk</label>
                                <input type="text" class="form-control" name="nama" value="<?= $warga['nama']; ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Alamat</label>
                                <input type="text" class="form-control" name="alamat" value="<?= $warga['alamat']; ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Tanggal Lahir</label>
                                <input type="date" class="form-control" name="tgl_lahir" value="<?= $warga['tgl_lahir']; ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>No. Telepon</label>
                                <input type="text" maxlength="13" class="form-control" name="no_hp" value="<?= $warga['no_hp']; ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                                    <option selected disabled value="">-- Pilih jenis Kelamin --</option>
                                    <option value="1" <?= $warga['jenis_kelamin'] == '1' ? 'selected' : ''; ?>>Laki-Laki</option>
                                    <option value="2" <?= $warga['jenis_kelamin'] == '2' ? 'selected' : ''; ?>>Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Agama</label>
                                <select class="form-control" id="agama" name="agama">
                                    <option selected disabled value="">-- Pilih Agama --</option>
                                    <option value="1" <?= $warga['agama'] == '1' ? 'selected' : ''; ?>>Islam</option>
                                    <option value="2" <?= $warga['agama'] == '2' ? 'selected' : ''; ?>>Protestan</option>
                                    <option value="3" <?= $warga['agama'] == '3' ? 'selected' : ''; ?>>Katolik</option>
                                    <option value="4" <?= $warga['agama'] == '4' ? 'selected' : ''; ?>>Hindu</option>
                                    <option value="5" <?= $warga['agama'] == '5' ? 'selected' : ''; ?>>Buddha</option>
                                    <option value="6" <?= $warga['agama'] == '6' ? 'selected' : ''; ?>>Khonghucu</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Pekerjaan</label>
                                <input type="text" class="form-control" name="pekerjaan" value="<?= $warga['pekerjaan']; ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-b$warga text-primary">Data Kebutuhan</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Pakaian Baru Per Tahun</label>
                                <select class="form-control" id="pakaian" name="pakaian">
                                    <option selected disabled value="">-- Pilih Pakaian Per Tahun --</option>
                                    <option value="1" <?= $warga['pakaian'] == '1' ? 'selected' : ''; ?>>Tidak Pernah</option>
                                    <option value="2" <?= $warga['pakaian'] == '2' ? 'selected' : ''; ?>>1 Stel</option>
                                    <option value="3" <?= $warga['pakaian'] == '3' ? 'selected' : ''; ?>>2 Stel</option>
                                    <option value="4" <?= $warga['pakaian'] == '4' ? 'selected' : ''; ?>>3 Stel</option>
                                    <option value="5" <?= $warga['pakaian'] == '5' ? 'selected' : ''; ?>>Lebih Dari 3 Stel</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Biaya Pengobatan</label>
                                <select class="form-control" id="biaya_pengobatan" name="biaya_pengobatan">
                                    <option selected disabled value="">-- Pilih Biaya Pengobatan --</option>
                                    <option value="1" <?= $warga['biaya_pengobatan'] == '1' ? 'selected' : ''; ?>>BPJS Gratis</option>
                                    <option value="2" <?= $warga['biaya_pengobatan'] == '2' ? 'selected' : ''; ?>>BPJS Mandiri</option>
                                    <option value="3" <?= $warga['biaya_pengobatan'] == '3' ? 'selected' : ''; ?>>Lainnya</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Makanan Per Hari</label>
                                <select class="form-control" id="makanan_per_hari" name="makanan_per_hari">
                                    <option selected disabled value="">-- Pilih Banyak Makanan Dalam Sehari --</option>
                                    <option value="1" <?= $warga['makanan_per_hari'] == '1' ? 'selected' : ''; ?>>Tidak Makanan</option>
                                    <option value="2" <?= $warga['makanan_per_hari'] == '2' ? 'selected' : ''; ?>>1 Kali Sehari</option>
                                    <option value="3" <?= $warga['makanan_per_hari'] == '3' ? 'selected' : ''; ?>>2 Kali Sehari</option>
                                    <option value="4" <?= $warga['makanan_per_hari'] == '4' ? 'selected' : ''; ?>>3 Kali Sehari</option>
                                    <option value="5" <?= $warga['makanan_per_hari'] == '5' ? 'selected' : ''; ?>>Lebih 3 Kali Sehari</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-b$warga text-primary">Data Bantuan</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">

                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Penerima Bantuan</label>
                                <select class="form-control" id="penerima_bantuan" name="penerima_bantuan">
                                    <option selected disabled value="">-- Pilih Jenis Penerima Bantuan --</option>
                                    <option value="1" <?= $warga['penerima_bantuan'] == '1' ? 'selected' : ''; ?>>BPNT</option>
                                    <option value="2" <?= $warga['penerima_bantuan'] == '2' ? 'selected' : ''; ?>>PKH</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <button class="btn btn-primary btn-user btn-block mb-5" type="submit">
        Simpan
    </button>
</form>

<?= $this->endsection(); ?>