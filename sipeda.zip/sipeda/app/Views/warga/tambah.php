<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="row mb-4">
    <div class="col-8">
        <h3><?= $title; ?></h3>
        <?php
        $errors = session()->getFlashdata('errors');
        if (!empty($errors)) { ?>
            <div class="alert alert-danger alert-dismissible">
                <ul>
                    <?php foreach ($errors as $key => $value) { ?>
                        <li><?= esc($value); ?></li>
                    <?php } ?>
                </ul>
            </div>
        <?php } ?>
    </div>
</div>

<form method="post" action="/warga/add">
    <?= csrf_field(); ?>
    <div class="row">
        <div class="col-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Data Individu</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>No. KK</label>
                                <input type="text" maxlength="16" class="form-control" name="no_kk" value="<?= old('no_kk'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>NIK</label>
                                <input type="text" maxlength="16" class="form-control" name="nik" value="<?= old('nik'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Nama Penduduk</label>
                                <input type="text" class="form-control" name="nama" value="<?= old('nama'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Alamat</label>
                                <input type="text" class="form-control" name="alamat" value="<?= old('alamat'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Tanggal Lahir</label>
                                <input type="date" class="form-control" name="tgl_lahir" value="<?= old('tgl_lahir'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>No. Telepon</label>
                                <input type="text" maxlength="13" class="form-control" name="no_hp" value="<?= old('no_hp'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                                    <option selected disabled value="">-- Pilih jenis Kelamin --</option>
                                    <option value="1" <?= old('jenis_kelamin') == '1' ? 'selected' : ''; ?>>Laki-Laki</option>
                                    <option value="2" <?= old('jenis_kelamin') == '2' ? 'selected' : ''; ?>>Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Agama</label>
                                <select class="form-control" id="agama" name="agama">
                                    <option selected disabled value="">-- Pilih Agama --</option>
                                    <option value="1" <?= old('agama') == '1' ? 'selected' : ''; ?>>Islam</option>
                                    <option value="2" <?= old('agama') == '2' ? 'selected' : ''; ?>>Protestan</option>
                                    <option value="3" <?= old('agama') == '3' ? 'selected' : ''; ?>>Katolik</option>
                                    <option value="4" <?= old('agama') == '4' ? 'selected' : ''; ?>>Hindu</option>
                                    <option value="5" <?= old('agama') == '5' ? 'selected' : ''; ?>>Buddha</option>
                                    <option value="6" <?= old('agama') == '6' ? 'selected' : ''; ?>>Khonghucu</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Pekerjaan</label>
                                <input type="text" class="form-control" name="pekerjaan" value="<?= old('pekerjaan'); ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Data Kebutuhan</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Pakaian Baru Per Tahun</label>
                                <select class="form-control" id="pakaian" name="pakaian">
                                    <option selected disabled value="<?= old('pakaian'); ?>">-- Pilih Pakaian Per Tahun --</option>
                                    <option value="1" <?= old('pakaian') == '1' ? 'selected' : ''; ?>>Tidak Pernah</option>
                                    <option value="2" <?= old('pakaian') == '2' ? 'selected' : ''; ?>>1 Stel</option>
                                    <option value="3" <?= old('pakaian') == '3' ? 'selected' : ''; ?>>2 Stel</option>
                                    <option value="4" <?= old('pakaian') == '4' ? 'selected' : ''; ?>>3 Stel</option>
                                    <option value="5" <?= old('pakaian') == '5' ? 'selected' : ''; ?>>Lebih Dari 3 Stel</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Biaya Pengobatan</label>
                                <select class="form-control" id="biaya_pengobatan" name="biaya_pengobatan">
                                    <option selected disabled value="<?= old('biaya_pengobatan'); ?>">-- Pilih Biaya Pengobatan --</option>
                                    <option value="1" <?= old('biaya_pengobatan') == '1' ? 'selected' : ''; ?>>BPJS Gratis</option>
                                    <option value="2" <?= old('biaya_pengobatan') == '2' ? 'selected' : ''; ?>>BPJS Mandiri</option>
                                    <option value="3" <?= old('biaya_pengobatan') == '3' ? 'selected' : ''; ?>>Lainnya</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Makanan Per Hari</label>
                                <select class="form-control" id="makanan_per_hari" name="makanan_per_hari">
                                    <option selected disabled value="<?= old('makanan_per_hari'); ?>">-- Pilih Banyak Makanan Dalam Sehari --</option>
                                    <option value="1" <?= old('makanan_per_hari') == '1' ? 'selected' : ''; ?>>Tidak Makanan</option>
                                    <option value="2" <?= old('makanan_per_hari') == '2' ? 'selected' : ''; ?>>1 Kali Sehari</option>
                                    <option value="3" <?= old('makanan_per_hari') == '3' ? 'selected' : ''; ?>>2 Kali Sehari</option>
                                    <option value="4" <?= old('makanan_per_hari') == '4' ? 'selected' : ''; ?>>3 Kali Sehari</option>
                                    <option value="5" <?= old('makanan_per_hari') == '5' ? 'selected' : ''; ?>>Lebih 3 Kali Sehari</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Data Bantuan</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">

                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Penerima Bantuan</label>
                                <select class="form-control" id="penerima_bantuan" name="penerima_bantuan">
                                    <option selected disabled value="">-- Pilih Jenis Penerima Bantuan --</option>
                                    <option value="1" <?= old('penerima_bantuan') == '1' ? 'selected' : ''; ?>>BPNT</option>
                                    <option value="2" <?= old('penerima_bantuan') == '2' ? 'selected' : ''; ?>>PKH</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <button class="btn btn-primary btn-user btn-block mb-5" type="submit">
        Simpan
    </button>
</form>

<?= $this->endsection(); ?>