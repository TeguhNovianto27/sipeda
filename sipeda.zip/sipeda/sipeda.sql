-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2024 at 06:02 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sipeda`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

CREATE TABLE `auth` (
  `id_auth` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `nama_pengguna` varchar(60) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `role` enum('1','2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth`
--

INSERT INTO `auth` (`id_auth`, `tanggal`, `nama_pengguna`, `username`, `password`, `role`) VALUES
(1, '2024-01-08 03:25:40', 'ADMIN DATA', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', '1'),
(2, '2024-01-09 04:34:51', 'Petugas 1', 'petugasdata', '7af2d10b73ab7cd8f603937f7697cb5fe432c7ff', '2');

-- --------------------------------------------------------

--
-- Table structure for table `disabilitas`
--

CREATE TABLE `disabilitas` (
  `id_disabilitas` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `nik` varchar(11) NOT NULL,
  `nama` varchar(60) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `jenis_kelamin` enum('1','2') NOT NULL,
  `jenis_disabilitas` enum('1','2','3','4') NOT NULL,
  `kebutuhan` enum('1','2','3','4','5','6','7','8','9') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `disabilitas`
--

INSERT INTO `disabilitas` (`id_disabilitas`, `tanggal`, `nik`, `nama`, `tgl_lahir`, `alamat`, `jenis_kelamin`, `jenis_disabilitas`, `kebutuhan`) VALUES
(1, '2024-01-07 01:34:25', '23232732636', 'coba', '2023-08-16', 'coba', '1', '4', '9'),
(2, '2024-01-07 01:40:06', '23232732636', 'coba20', '2023-03-09', 'coba', '2', '4', '9'),
(3, '2024-01-09 04:27:22', '54658653657', 'teguh', '2024-01-08', 'PEKALONGAN', '1', '1', '2');

-- --------------------------------------------------------

--
-- Table structure for table `warga`
--

CREATE TABLE `warga` (
  `id_warga` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(60) NOT NULL,
  `alamat` text NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` enum('1','2') NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `agama` enum('1','2','3','4') NOT NULL,
  `pekerjaan` varchar(40) NOT NULL,
  `pakaian` enum('1','2','3','4','5') NOT NULL,
  `biaya_pengobatan` enum('1','2','3') NOT NULL,
  `makanan_per_hari` enum('1','2','3','4','5') NOT NULL,
  `penerima_bantuan` enum('1','2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `warga`
--

INSERT INTO `warga` (`id_warga`, `tanggal`, `no_kk`, `nik`, `nama`, `alamat`, `tgl_lahir`, `jenis_kelamin`, `no_hp`, `agama`, `pekerjaan`, `pakaian`, `biaya_pengobatan`, `makanan_per_hari`, `penerima_bantuan`) VALUES
(1, '2024-01-07 12:36:25', '0237237237273672', '2323273263626732', 'coba', 'coba', '2024-01-07', '2', '0878873643', '3', 'Karyawan Swasta', '3', '1', '3', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id_auth`);

--
-- Indexes for table `disabilitas`
--
ALTER TABLE `disabilitas`
  ADD PRIMARY KEY (`id_disabilitas`);

--
-- Indexes for table `warga`
--
ALTER TABLE `warga`
  ADD PRIMARY KEY (`id_warga`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth`
--
ALTER TABLE `auth`
  MODIFY `id_auth` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `disabilitas`
--
ALTER TABLE `disabilitas`
  MODIFY `id_disabilitas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `warga`
--
ALTER TABLE `warga`
  MODIFY `id_warga` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
